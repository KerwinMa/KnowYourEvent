Release Notes:

	- Samples included in downloadable source code named Linq2TwitterDemos_<technology>.
	- How to use with Google Glass: 
		http://geekswithblogs.net/WinAZ/archive/2014/01/10/watch-linq-to-twitter-on-glass.aspx
	- How to use with Xamarin.Android: 
		http://geekswithblogs.net/WinAZ/archive/2013/11/14/linq-to-twitter-runs-xamarin.android.aspx
	- How to use with Xamarin.iOS: 
		http://geekswithblogs.net/WinAZ/archive/2013/12/06/linq-to-twitter-runs-on-xamarin.ios.aspx

Assemblies:

Primary DLL

	LinqToTwitterPcl.dll

ASP.NET Authorizers

	LinqToTwitter.AspNet.dll

Windows Store Authorizers

	LinqToTwitter.WindowsStore.dll

Required Dependencies (HttpClient, Compression, and RX)

  Microsoft.Bcl.dll
  Microsoft.Bcl.Build.dll
  Microsoft.Bcl.Compression.dll
  Microsoft.Net.Http.dll
  Rx-Core.dll
  Rx-Interfaces.dll
  Rx-Linq.dll
  Rx-Main.dll
  Rx-PlatformServices.dll
  
Follow @JoeMayo and @Linq2Twitr on Twitter for the latest news.

